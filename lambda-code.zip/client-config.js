"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class AuthenticationConfig {
}
exports.AuthenticationConfig = AuthenticationConfig;
class AssistantConfig {
}
exports.AssistantConfig = AssistantConfig;
class AudioConfig {
}
exports.AudioConfig = AudioConfig;
class Config {
}
exports.Config = Config;
