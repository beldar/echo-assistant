"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class AuthenticationConfig {
}
exports.AuthenticationConfig = AuthenticationConfig;
class HotwordConfig {
}
exports.HotwordConfig = HotwordConfig;
class HotwordsConfig {
}
exports.HotwordsConfig = HotwordsConfig;
class AssistantConfig {
}
exports.AssistantConfig = AssistantConfig;
class AudioConfig {
}
exports.AudioConfig = AudioConfig;
class RecordConfig {
}
exports.RecordConfig = RecordConfig;
class Config {
}
exports.Config = Config;
//# sourceMappingURL=client-config.js.map