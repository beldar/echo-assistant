"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const index_1 = require("./index");
const payload = require('./payload.json');
index_1.handlers.Assist.bind({ event: payload, emit: (action, msg) => console.log(action, msg) })();
