var jspb = require('google-protobuf');
var goog = jspb;
var global = Function('return this')();
var google_api_http_pb = require('../../google/api/http_pb.js');
var google_protobuf_descriptor_pb = require('google-protobuf/google/protobuf/descriptor_pb.js');
goog.exportSymbol('proto.google.api.http', null, global);
proto.google.api.http = new jspb.ExtensionFieldInfo(72295728, { http: 0 }, google_api_http_pb.HttpRule, (google_api_http_pb.HttpRule.toObject), 0);
google_protobuf_descriptor_pb.MethodOptions.extensionsBinary[72295728] = new jspb.ExtensionFieldBinaryInfo(proto.google.api.http, jspb.BinaryReader.prototype.readMessage, jspb.BinaryWriter.prototype.writeMessage, google_api_http_pb.HttpRule.serializeBinaryToWriter, google_api_http_pb.HttpRule.deserializeBinaryFromReader, false);
google_protobuf_descriptor_pb.MethodOptions.extensions[72295728] = proto.google.api.http;
goog.object.extend(exports, proto.google.api);
//# sourceMappingURL=annotations_pb.js.map